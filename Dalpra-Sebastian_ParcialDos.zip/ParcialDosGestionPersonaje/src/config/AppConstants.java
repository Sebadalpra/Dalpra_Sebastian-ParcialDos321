
package config;

/**
 *
 * @author Sebas
 */
public class AppConstants {
    public static final String PATH_FILES = "src/data/";
    public static final String FILE_BIN = PATH_FILES + "personajes.dat";
    public static final String FILE_CSV = PATH_FILES + "personajes.csv";
}
