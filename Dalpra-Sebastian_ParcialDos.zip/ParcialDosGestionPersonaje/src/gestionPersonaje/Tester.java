package gestionPersonaje;

import config.AppConstants;
import modelo.*;
import java.io.IOException;

public class Tester {
    public static void main(String[] args) {
        try {
            
            // Crear un inventario de personajes jugables
            Inventario<Personaje> inventarioPersonajes = new Inventario<>();
            inventarioPersonajes.agregar(new Personaje(1, "Aragorn", ClasePersonaje.GUERRERO, 20));
            inventarioPersonajes.agregar(new Personaje(2, "Gandalf", ClasePersonaje.MAGO, 50));
            inventarioPersonajes.agregar(new Personaje(3, "Legolas", ClasePersonaje.ARQUERO, 25));
            inventarioPersonajes.agregar(new Personaje(4, "Frodo", ClasePersonaje.GUERRERO, 10));
            inventarioPersonajes.agregar(new Personaje(5, "Saruman", ClasePersonaje.MAGO, 40));
            inventarioPersonajes.agregar(new Personaje(6, "Robin Hood", ClasePersonaje.ARQUERO, 30));

            // Mostrar todos los personajes en el inventario
            System.out.println("Inventario de personajes:");
            inventarioPersonajes.paraCadaElemento(personaje -> System.out.println(personaje));

            // Ordenar personajes de manera natural (por nombre)
            System.out.println("\nPersonajes ordenados por nombre:");
            inventarioPersonajes.ordenar();
            inventarioPersonajes.paraCadaElemento(personaje -> System.out.println(personaje));

            // Ordenar personajes por nivel utilizando un Comparator
            System.out.println("\nPersonajes ordenados por nivel:");
            inventarioPersonajes.ordenar((p1, p2) -> Integer.compare(p1.getNivel(), p2.getNivel()));
            inventarioPersonajes.paraCadaElemento(personaje -> System.out.println(personaje));

            // Filtrar personajes de clase MAGO

            System.out.println("\nPersonajes de la clase MAGO:");
            inventarioPersonajes.filtrar(personaje -> personaje.getClase() == ClasePersonaje.MAGO)
                                .forEach(personaje -> System.out.println(personaje));

            // Transformar personajes: aumentar nivel en +5
            System.out.println("\nAumentando nivel de todos los personajes en +5:");
            inventarioPersonajes.transformar(personaje -> {
                personaje.setNivel(personaje.getNivel() + 5);
                return personaje;
            });
            inventarioPersonajes.paraCadaElemento(personaje -> System.out.println(personaje));

            // Guardar y cargar desde archivo binario
            inventarioPersonajes.guardarEnArchivo(AppConstants.FILE_BIN);
            
            // Cargar el inventario desde el archivo binario:
            Inventario<Personaje> inventarioCargado = new Inventario<>();
            inventarioCargado.cargarDesdeArchivo(AppConstants.FILE_BIN);
            System.out.println("\nPersonajes cargados desde archivo binario:");
            inventarioCargado.paraCadaElemento(personaje -> System.out.println(personaje));

            // Guardar y cargar desde CSV
            inventarioPersonajes.guardarEnCSV(AppConstants.FILE_CSV);
            
            // Cargar el inventario desde el archivo CSV
            inventarioCargado.cargarDesdeCSV(AppConstants.FILE_CSV, linea -> Personaje.fromCSV(linea));
            System.out.println("\nPersonajes cargados desde archivo CSV:");
            inventarioCargado.paraCadaElemento(personaje -> System.out.println(personaje));

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
