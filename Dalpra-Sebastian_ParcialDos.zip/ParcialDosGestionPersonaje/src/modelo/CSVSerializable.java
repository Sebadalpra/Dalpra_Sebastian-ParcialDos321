package modelo;

/**
 *
 * @author Sebas
 */
public interface CSVSerializable {
    String toCSV();
}