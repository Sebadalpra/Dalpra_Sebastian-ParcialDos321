
package modelo;

import java.io.Serializable;

/**
 *
 * @author Sebas
 */
public class Personaje implements Comparable<Personaje>, CSVSerializable, Serializable{
    private int id;
    private String nombre;
    private ClasePersonaje clase;
    private int nivel;

    public Personaje(int id, String nombre, ClasePersonaje clase, int nivel) {
        this.id = id;
        this.nombre = nombre;
        this.clase = clase;
        this.nivel = nivel;
    }
    
    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public ClasePersonaje getClase() {
        return clase;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    @Override
    public String toString() {
        return "Personaje{" + "id=" + id + ", nombre=" + nombre + ", clase=" + clase + ", nivel=" + nivel + '}';
    }
    
    @Override
    public int compareTo(Personaje otro) {
        return this.nombre.compareTo(otro.nombre);
    }
    
    // CSV:

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + clase + "," + nivel;
    }
    
    public static Personaje fromCSV(String csvLine){
        String[] parts = csvLine.split(",");
        if (parts.length != 4) {
            throw new IllegalArgumentException("Formato CSV incorrecto");
        }
        int id = Integer.parseInt(parts[0]);
        String nombre = parts[1];
        ClasePersonaje clase = ClasePersonaje.valueOf(parts[2]);
        int nivel = Integer.parseInt(parts[3]);
        return new Personaje(id, nombre, clase, nivel);
    }
    
    
}
