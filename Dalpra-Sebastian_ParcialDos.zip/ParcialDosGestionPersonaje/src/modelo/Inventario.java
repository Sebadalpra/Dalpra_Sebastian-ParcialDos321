package modelo;

/**
 *
 * @author Sebas
 */
import java.io.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class Inventario<T extends CSVSerializable> {
    private List<T> lista = new ArrayList<>();

    public void agregar(T item) {
        if (item == null) {
            throw new NullPointerException();
        }
        lista.add(item);
    }
    
    private void validarRango(int indice) {
        if (indice < 0) {
            throw new IllegalArgumentException();
        }
        if (indice >= lista.size()) {
            throw new ArrayIndexOutOfBoundsException("Indice fuera del rango.");
        }
    }

    public void eliminar(int indice) {
        validarRango(indice);
        lista.remove(indice);
    }

    public void paraCadaElemento(Consumer<? super T> accion) {
        lista.forEach(accion);
    }

    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> filtrados = new ArrayList<>();
        for (T item : lista) {
            if (criterio.test(item)) {
                filtrados.add(item);
            }
        }
        return filtrados;
    }

        // subir nivel + 5
    public void transformar(Function<T, T> transformador) {
        if (transformador == null) {
            throw new IllegalArgumentException("el transformador no puede ser null");
        }
        for (int i = 0; i < lista.size(); i++) {
            validarRango(i); 
            T elementoTransformado = transformador.apply(lista.get(i));
            lista.set(i, elementoTransformado);
        }
    }

    public void ordenar() {
        lista.sort(null);
    }

    public void ordenar(Comparator<? super T> comparator) {
        lista.sort(comparator);
    }
    
    // todo lo de archivos:

    public void guardarEnArchivo(String path) throws IOException {
        try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(path))) {
            output.writeObject(lista);
        }
    }

    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))) {
            lista = (List<T>) input.readObject();
        }
    }

    public void guardarEnCSV(String path) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(path))) {
            // header
            writer.write("id,nombre,clase,nivel");
            writer.newLine();
            
            for (T item : lista) {
                writer.write(item.toCSV());
                writer.newLine();
            }
        }
    }

    public void cargarDesdeCSV(String path, Function<String, T> transformador) throws IOException {
        // limpair lista previamente
        lista.clear();

        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String linea;
            
            br.readLine(); // omitir el header

            while ((linea = br.readLine()) != null) {
                lista.add(transformador.apply(linea));
            }
        }
    }

}

