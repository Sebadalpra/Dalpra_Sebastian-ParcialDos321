
package modelo;

/**
 *
 * @author Sebas
 */
public enum ClasePersonaje {
    GUERRERO, MAGO, ARQUERO;
}
